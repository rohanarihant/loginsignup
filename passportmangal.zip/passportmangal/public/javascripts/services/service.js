app.service('createUser',function($location,$http,$localStorage){
this.signUpuser = function(name,username,email,password,gender,file){
      var uploadUrl = "api/signup";
        var fd = new FormData();
        fd.append('name',name);
        fd.append('username',username);
        fd.append('email',email);
        fd.append('password',password);
        fd.append('gender',gender);
        fd.append('file', file);
        $http.post(uploadUrl,fd, {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        }) .success(function(res){
         $localStorage.userData=res;
          //console.log($localStorage.userData)
          $location.path("/varifiEmail")
        })
        .error(function(){
          console.log("error!!");
        });
    };
});

app.factory('Auth', function($http,$location, $localStorage){
var userLog;
var log;
return{
  setUser : function(username,password){
       $http({
	method:"POST",
	url:'api/login',
	data:{username:username,password:password},
}).then(function successCallback(response) {
	   var  userLog=response.data;
     console.log(userLog);
       $localStorage.LoginUser=  userLog ;
  //log =$localStorage.LoginUser;
    //console.log($localStorage.LoginUser.local.username )
        $location.path('/home');
       //  if($localStorage.LoginUser.local.username == username && $localStorage.LoginUser.local.password == password){
       //   log=$localStorage.LoginUser;
       // 	alert("You are valid user");
       // 	$location.path('/home');
       // }else{
       // 	   	alert("You are not valid user plz sign in");
       // 	   		$location.path('/signUp');
       //  }
	}, function errorCallback(response) {
		  console.log('error');
		    alert("username or password is not valid");
		   $location.path('/signUp');
	});

    },
    isLoggedIn : function(){
    return (log)? log=true : log=false;
    console.log(log)
    },
     isLoggedOut : function(){
    return log =false;
    }
  }
  
});

