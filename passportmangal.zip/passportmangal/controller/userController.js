// var Usermodel = require('../model/userModel');
// var LocalStrategy   = require('passport-local').Strategy;
// var crypto = require('crypto');
// var bCrypt = require('bcrypt-nodejs');
// //var nodemailer = require('nodemailer');
// //var transporter = nodemailer.createTransport('smtps://rohansunpreet@gmail.com:mangalsing@smtp.gmail.com');
// // module.exports.signup=function(req,res){
// // var seed = crypto.randomBytes(20);
// //  var authToken = crypto.createHash('sha1').update(seed + req.body.email).digest('hex')
// //  //console.log(authToken)
// //         var newUser = new Usermodel();
// //           newUser.local.username = req.body.username;
// //           newUser.local.password = createHash(req.body.password);
// //           newUser.local.email = req.body.email;
// //           newUser.local.name = req.body.name;
// //           newUser.local.gender = req.body.gender;
// //           newUser.local.pic = req.file.filename;
// //           newUser.local.authToken = authToken;
// //           newUser.local.isAuthenticated=false;
// //           //newUser.save(function(err,newUser) {
// //   //send the randome number for email varrification
// // Usermodel.findOne({'local.username':req.body.username},function(err,person){
// // 	if(err){
// // 		console.log('err',err)
// // 	}else{
// // 		if(!person){
// // 			newUser.save(function(err,person){
// // 				if(err){
// // 					res.send(err);
// // 				}else{
// // var authenticationURL = 'http://localhost:3002/api/verify_email?token=' + newUser.local.authToken;
// //  console.log(authenticationURL)
// // //************send email
// // //var data = req.body;
// // var mailOptions={
// //     to:     newUser.local.email, // list of receivers
// //     from:  "mangalhcl449@gmail.com", // sender address
// //     subject: 'Confirm your email', // Subject line
// //     text: 'Hello world 🐴', // plaintext body
// //    html: '<a target=_blank href=\"' + authenticationURL + '\">Confirm your email</a>'
// // };
// // //console.log(mailOptions);
// // transporter.sendMail(mailOptions, function(error, info){
// //        if(error){
// //         return console.log(error);
// //      } 
// //        console.log(info);
// //         });
// // 		res.send(person);
// // 	//console.log(person);
// // 					//res.redirect("/login")
// // 				}
// // 			});
// // 		}else{
// // 			res.send({error:"Email is already taken"});
// // 		}
// // 	}

// // })
// // }
// //var Usermodel = require('/home/ram/nApp/model/createUser');
// var nodemailer = require('nodemailer');
// //var transporter = nodemailer.createTransport('smtps://mangalhcl449@gmail.com:welcome@123.com@smtp.gmail.com');
// //console.log(transporter)
// var transport = nodemailer.createTransport("SMTP", {
//     host: "smtp.gmail.com", // hostname
//     secureConnection: true, // use SSL
//     port: 465, // port for secure SMTP
//     auth: {
//         user: "mangalhcl449@gmail.com",
//         pass: "welcome@123.com"
//     }
// });
// // module.exports.verify = function(req,res){
// //   var confirmation = req.params.confirmation;

// //   Usermodel.findOne({confirmation:req.params.confirmation},function(err,data){
// //             if(err){
// //                 res.send(err);
// //             }
// //             else{
// //               res.send(data);
// //                 $scope.profile = res.send(data);
// //                 console.log(data);
// //             }
// //         })
// // }
// module.exports.signup = function(req,res){
//  var seed = crypto.randomBytes(20);
//  var authToken = crypto.createHash('sha1').update(seed + req.body.email).digest('hex')
//        //console.log(authToken)
//           var newUser = new Usermodel();
//           newUser.local.username = req.body.username;
//           newUser.local.password = createHash(req.body.password);
//           newUser.local.email = req.body.email;
//           newUser.local.name = req.body.name;
//           newUser.local.gender = req.body.gender;
//           newUser.local.pic = req.file.filename;
//           newUser.local.authToken = authToken;
//           newUser.local.isAuthenticated=false;
//   Usermodel.findOne({'local.email':req.body.email},function(err,person){
//   if(err){
//     console.log('err',err)
//   }else{
//     if(!person){
//       newUser.save(function(err,person){
//         if(err){
//           res.send(err);
//         }else{
// var authenticationURL = 'http://localhost:3002/api/verify_email?token=' + newUser.local.authToken;
//     console.log(authenticationURL)
//     var mailOptions = {
//     from: '"Mangal App" <mangalhcl449@gmail.com>', // sender address 
//     to: 'c.vicky1231990@gmail.com', // list of receivers 
//     subject: 'Confirm your account', // Subject line 
//     html: '<a target=_blank href=\"' + authenticationURL + '\">Confirm your email</a>'
   
// };
// // send mail with defined transport object 
// transport.sendMail(mailOptions, function(error, info){
//     if(error){
//         return console.log(error);
//     }
//     console.log('Message sent: ' + info.response);
//       });
//         res.send(person);
//             //console.log(data);
//         }
//         })
//       }else{
//         res.send({error:'email is already registered'});
//       }
//     }
//   })
// }

//  var createHash = function(password){
//         return bCrypt.hashSync(password, bCrypt.genSaltSync(10), null);
//     }
